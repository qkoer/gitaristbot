A modular telegram Python bot running on python3 with an sqlalchemy database. 


## Bu Yonetim Botu @qkoer Tarafindan DUZENLENMİSTİR Deploy Tusuna Basarak Deploy Edebilirsiniz.

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/emrecan001/tgbot)